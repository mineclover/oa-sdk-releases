# @oa-sdk/spec-bundler

Declarative manifest-driven asset bundler, AST-free markdown link rewriter, and dependency reachability engine with cryptographic lockfile freshness verification.

[![Zero Dependencies](https://img.shields.io/badge/dependencies-0-brightgreen.svg)](#zero-runtime-dependencies)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue.svg)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

---

## 1. Overview & Architecture Boundaries

`@oa-sdk/spec-bundler` is designed as a standalone, zero-dependency distribution packager within the specification ecosystem.

```mermaid
flowchart TD
    subgraph Ecosystem ["Specification Ecosystem Boundaries"]
        DP["@spec-platform/document-parser<br/>(Full AST & Knowledge Graph)"]
        TE["@samchon/typespec-evidence<br/>(Compile-time Verification & CI Gate)"]
        MB["@oa-sdk/spec-bundler<br/>(Zero-Dependency Bundler & Link Rewriter)"]
    end

    SRC["Source Specs & Documentation<br/>(Markdown, TypeSpec, Assets)"]
    SRC --> DP
    SRC --> TE
    SRC --> MB

    MB -->|1. BFS Reachability Traversal| TS["Tree-Shaking of Unused Docs"]
    MB -->|2. Regex Masking| LR["Relative Link Coordinate Rewriting"]
    MB -->|3. Anchor Integrity Auditing| AV["--check-anchors + 'Did you mean?'"]
    MB -->|4. Cryptographic BOM| PK["Deterministic ZIP Archive + Lockfile"]
```

### Architectural Directives:
- **Zero Runtime Dependencies**: Built strictly using Node.js built-ins (`node:fs`, `node:path`, `node:crypto`, `node:zlib`). Runs seamlessly via `npx` or `pnpm` without installing third-party parser runtimes.
- **AST-Free Parsing via Code Fence Masking**: Avoids heavy AST parsers. Protects multi-line code fences (```` ```...``` ````), inline spans (`` `...` ``), and HTML blocks with temporary token masking to rewrite Markdown links at line/character-accurate offsets without mutating code samples.
- **Single Source of Truth (SSOT) for Heading Slugs**: Implements GitHub-compliant Unicode slug normalization (`/[^\p{L}\p{N}\s-]/gu`), guaranteeing identical slug generation across Korean, CJK, and multilingual specifications.

---

## 2. Core Features

### 2.1 BFS Tree-Shaking Reachability Traversal
When `treeShake: true` is configured with entrypoints (e.g. `["META-GUIDE.md", "AGENTS.md"]`), the bundler performs a Breadth-First Search (BFS) over internal document links and TypeSpec `@evidence` citations:
- Retains only explicitly referenced specifications, skills, and assets.
- Automatically excludes unreferenced legacy guides, templates, and intermediate scratch files.
- Operates safely on cyclic links and multi-hop references.

### 2.2 Automated Markdown Link Rewriting
- **Coordinate Recalculation**: Automatically updates relative paths when documents move to new positions in the bundle hierarchy.
- **Protocol Normalization**: Converts absolute local `file:///...` links to portable bundle-relative paths.
- **Fragment & Query Preservation**: Preserves URL fragments (`#heading-slug`) and search parameters (`?view=detail`).
- **Reference Definition Support**: Seamlessly parses and rewrites CommonMark link reference definitions (`[id]: path/to/doc.md`).
- **Unbundled Policy**: Configurable behavior for links pointing outside the bundle:
  - `warn`: Emits a diagnostic warning.
  - `error`: Blocks packaging with exit code 1.
  - `preserve`: Retains the link as-is.
  - `github-fallback`: Rewrites to GitHub repository URLs (using `gitRepositoryUrl`).

### 2.3 Comprehensive Anchor Verification (`--check-anchors`)
- Validates **intra-file anchors** (`[link](#heading)`) and **cross-file anchors** (`[link](./doc.md#heading)`).
- Extracts heading slugs, explicit custom IDs (`{#custom-id}`), and HTML anchors (`<a id="...">`).
- Employs a zero-dependency **Levenshtein distance matcher** to provide intelligent "Did you mean?" suggestions for broken anchor links.

### 2.4 TypeSpec (`.tsp`) Bundle Reference Rewriting
- Automatically rewrites outbound references in TypeSpec files during bundle assembly:
  - `@evidence("path/to/doc.md#anchor", "reason")` rewritten to point to bundle-internal destination coordinates.
  - Relative TypeSpec imports (`import "./common.tsp";`) rewritten to new bundle layout.
  - Markdown links embedded within `@doc("... [Link](path) ...")` or `@doc("""...""")` rewritten.
- Validates TypeSpec outbound references during `spec-bundler verify` with dead link detection and anchor fuzzy suggestions.

### 2.5 Embedded Path-Mapping BOM & Bundle Path Resolver
- Automatically embeds bidirectional path mappings in `META-INF/bundle.manifest.json`:
  - `sourceToBundle`: Maps repository source paths to bundle-internal coordinates.
  - `bundleToSource`: Maps bundle-internal coordinates back to original workspace source paths.
- Provides `spec-bundler resolve` CLI and `resolveBundlePath()` API to instantly locate any workspace path or reference (including `#anchor` and `?query`) within a packaged archive with Levenshtein typo suggestions.

### 2.6 Cryptographic Freshness & CI Gate
- Tracks content hashes (SHA-256) of all bundled files in `bundle.manifest.lock.json`.
- `spec-bundler check`: Instantaneous CI pre-commit gate (exits with code 1 if upstream sources drifted without regenerating the bundle).
- Emits GitHub Actions workflow annotations (`::error file=...::...`) automatically in CI environments.

### 2.7 Developer Experience & Visibility
- **Dry-Run Preview (`--dry-run`)**: Simulates destination mappings, planned link rewrites, and lockfile updates with zero disk writes.
- **Structured JSON (`--json`)**: Emits machine-readable output for orchestration pipelines.
- **Detailed Diff Reporting (`--diff`)**: Prints terminal-colored line-by-line link rewriting plans.
- **Visual ASCII Reachability Tree (`spec-bundler inspect`)**: Renders hierarchical entrypoint-to-dependency dependency trees.
- **Reachability Provenance (`spec-bundler pack --explain <target>`)**: Explains exactly *why* a file was retained across hop-by-hop reference chains.
- **JSON Schema Draft 2020-12 (`spec-bundler schema`)**: Emits and validates manifest configurations with typo detection.

---

## 3. CLI Usage Reference

```bash
# Package the bundle (auto-detects evidence-bundle.manifest.json or bundle.manifest.json)
spec-bundler pack

# Preview packaging with zero disk writes
spec-bundler pack --dry-run

# Output detailed terminal diff reporting of planned rewrites
spec-bundler pack --dry-run --diff

# Output structured machine-readable JSON
spec-bundler pack --dry-run --json

# Explain why a specific file was retained in the bundle
spec-bundler pack --explain architecture-guides/core-flow.md

# Force re-bundle even if files are fresh
spec-bundler pack --force

# Inspect hierarchical ASCII dependency reachability tree
spec-bundler inspect

# CI Gate: verify that bundle and lockfile are fresh
spec-bundler check

# Audit bundle links and verify anchor validity with fuzzy suggestions
spec-bundler verify --check-anchors

# Resolve workspace path or reference inside packaged bundle
spec-bundler resolve dist/bundle.zip docs/requirements.md#user-profile
spec-bundler resolve dist/bundle.zip docs/requirements.md#user-profile --json

# Emit official JSON Schema (Draft 2020-12) for manifests
spec-bundler schema --out docs/bundle-manifest.schema.json

# Extract a bundle archive cleanly into a target directory
spec-bundler unpack dist/bundle.zip --dest .agents/skills/
```

---

## 4. Manifest Configuration (`bundle.manifest.json`)

```json
{
  "$schema": "https://spec-platform.dev/schemas/bundle-manifest.v1.json",
  "name": "evidence-meta-skill-bundle",
  "version": "1.0.0",
  "description": "Evidence meta skills and architecture contracts",
  "archive": {
    "output": "dist/evidence-bundle.zip"
  },
  "treeShake": true,
  "entrypoints": [
    "META-GUIDE.md",
    "AGENTS.md"
  ],
  "targets": [
    {
      "source": "docs/**/*.md",
      "dest": "docs/",
      "include": ["**/*.md"]
    },
    {
      "source": ".agents/skills/**",
      "dest": "skills/"
    },
    {
      "source": "specs/**/*.tsp",
      "dest": "specs/"
    }
  ],
  "exclude": [
    "**/node_modules/**",
    "**/.git/**",
    "**/tmp/**"
  ],
  "unbundledPolicy": "warn",
  "gitRepositoryUrl": "https://github.com/organization/repository"
}
```

---

## 5. Programmatic API

`@oa-sdk/spec-bundler` can be imported directly in Node.js / TypeScript:

```typescript
import {
  createBundle,
  verifyBundle,
  checkFreshness,
  inspectBundle,
  explainReachability,
  resolveBundlePath,
  rewriteTypeSpecContent,
  loadManifest,
  normalizeSlug,
  extractDocumentAnchors,
} from "@oa-sdk/spec-bundler";

// 1. Pack bundle programmatically
const result = await createBundle("bundle.manifest.json", {
  dryRun: false,
  force: false,
});
console.log(`Generated ${result.outputPath} (${result.filesCount} files)`);

// 2. Resolve references inside a bundle archive
const resolution = resolveBundlePath(
  result.outputPath,
  "docs/requirements.md#user-profile",
);
console.log(resolution.bundlePath); // "docs/requirements.md"
console.log(resolution.fullReference); // "docs/requirements.md#user-profile"

// 3. Audit links and anchors
const { freshness, deadLinks, warnings } = verifyBundle("bundle.manifest.json", {
  checkAnchors: true,
});
if (deadLinks.length > 0) {
  console.error("Dead links found:", deadLinks);
}

// 4. Inspect dependency reachability tree
const tree = inspectBundle("bundle.manifest.json");
console.log(tree.asciiTree);

// 5. Trace reachability provenance
const explanation = explainReachability("bundle.manifest.json", "docs/guide.md");
console.log(explanation.retained ? `Retained via: ${explanation.chain?.join(" -> ")}` : "Eliminated");
```

---

## 6. Conformance & Tolerance Rules

| Rule | Specification | Example |
| :--- | :--- | :--- |
| **Unicode Slugification** | `/[^\p{L}\p{N}\s-]/gu` + `replace(/\s+/g, "-")` | `## 사용자 계정 검증` → `사용자-계정-검증` |
| **Explicit Custom Anchor** | `{#custom-id}` syntax | `### 주문 정책 {#ca-order-policy}` → `ca-order-policy` |
| **Dash Collapsing** | `replace(/-+/g, "-")` | `1. 개요 & 설정` → `1-개요-설정` |
| **Numeric Prefix Tolerance** | Strips leading `^\d+[\.\)]\s*` | `1. 개요` matches `#1-개요` and `#개요` |
| **HTML Anchors** | Matches `<a id="...">` and `<a name="...">` | `<a id="overview">` → `overview` |
| **Fuzzy Suggestion** | Levenshtein distance $\le 3$ or substring ratio | `#user-prfole` → `(Did you mean '#user-profile'?)` |
